<?php

homepress_pagination( 'homepress_pagination' );

wp_reset_postdata();
