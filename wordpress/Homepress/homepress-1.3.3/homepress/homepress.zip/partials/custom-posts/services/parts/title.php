<div class="services-title">

    <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
        <h2><?php the_title(); ?></h2>
    </a>

</div>