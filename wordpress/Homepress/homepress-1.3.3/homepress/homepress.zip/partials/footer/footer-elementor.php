<?php
    if ( function_exists( 'hfe_render_footer' ) ) {
        hfe_render_footer();
    }