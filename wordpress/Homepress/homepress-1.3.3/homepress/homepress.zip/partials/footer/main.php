<?php

$footer_type = (defined('HFE_VER')) ? 'elementor' : 'default';

get_template_part('partials/footer/footer', $footer_type);