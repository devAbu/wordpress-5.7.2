<h1 class="site-title">
    <?php the_title(); ?>
</h1>