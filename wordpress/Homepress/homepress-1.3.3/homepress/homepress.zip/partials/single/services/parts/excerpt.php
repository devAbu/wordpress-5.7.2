<?php if ( has_excerpt() ) : ?>
    <div class="single-services-excerpt">
        <?php the_excerpt(); ?>
    </div>
<?php endif; ?>