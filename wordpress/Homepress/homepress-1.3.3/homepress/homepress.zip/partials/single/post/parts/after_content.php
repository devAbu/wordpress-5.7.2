<?php

get_template_part('partials/single/post/parts/prev_next_buttons');

get_template_part('partials/single/post/parts/comments');