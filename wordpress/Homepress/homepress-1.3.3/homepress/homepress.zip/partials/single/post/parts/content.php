<div class="single-post-content">
    <?php
        the_content();
    ?>
</div>