<div class="archive-post_content">

    <?php get_template_part('partials/post/parts/featured_image' ); ?>

    <div class="content-info">

        <div class="content-info-date">

            <?php get_template_part('partials/post/parts/posted_on_custom' ); ?>

        </div>

        <div class="content-info-content">

            <?php

            get_template_part('partials/post/parts/title' );

            get_template_part('partials/post/parts/excerpt' );

            ?>

        </div>

    </div>

</div>