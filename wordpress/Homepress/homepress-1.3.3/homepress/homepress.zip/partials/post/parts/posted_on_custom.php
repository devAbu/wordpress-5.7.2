<div class="posted-on-custom">

    <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
        <span class="post-date"><?php echo get_the_date( 'j' ); ?></span>
        <span class="post-month"><?php echo get_the_date( 'M' ); ?></span>
    </a>

</div>