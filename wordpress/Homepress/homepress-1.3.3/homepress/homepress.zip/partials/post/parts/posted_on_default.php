<div class="posted-on">

    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
        <?php echo get_the_date(); ?>
    </a>

</div>