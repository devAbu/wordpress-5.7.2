<?php
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/buttons/buttons.php';
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/image_carousel/image_carousel.php';
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/infobox/infobox.php';
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/staff/staff.php';
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/tabs/tabs.php';
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/testimonials/testimonials.php';
require_once get_template_directory() . '/inc/admin/css/theme_options/elementor/ulisting/ulisting.php';