<div class="listing-type-list">
    <span><?php echo esc_attr( $model->getType()->post_title ); ?></span>
</div>